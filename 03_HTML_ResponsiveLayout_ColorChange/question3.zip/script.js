// JavaScript to change the section color based on button click
document.getElementById('blue').addEventListener('click', function() {
    document.getElementById('color-section').style.backgroundColor = 'blue';
});

document.getElementById('orange').addEventListener('click', function() {
    document.getElementById('color-section').style.backgroundColor = 'orange';
});

document.getElementById('green').addEventListener('click', function() {
    document.getElementById('color-section').style.backgroundColor = 'green';
});
